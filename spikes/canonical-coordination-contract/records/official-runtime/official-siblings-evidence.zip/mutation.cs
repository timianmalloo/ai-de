using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text.Json;

internal static class Program
{
    private static void Main(string[] args)
    {
        if (args.Length != 3) throw new ArgumentException("Expected input DLL, isolated output DLL, SHA256.");
        var bytes = File.ReadAllBytes(args[0]);
        var before = Convert.ToHexString(SHA256.HashData(bytes));
        if (!string.Equals(before, args[2], StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Mutation input identity changed.");
        using var pe = new PEReader(new MemoryStream(bytes));
        var metadata = pe.GetMetadataReader();
        var typeHandle = metadata.TypeDefinitions.Single(handle =>
        {
            var type = metadata.GetTypeDefinition(handle);
            return metadata.GetString(type.Namespace) == "AiDe.Core.Watcher"
                && metadata.GetString(type.Name) == "SqliteWatcherObservationStore";
        });
        var methodHandle = metadata.GetTypeDefinition(typeHandle).GetMethods().Single(handle =>
            metadata.GetString(metadata.GetMethodDefinition(handle).Name) == "ProjectOfficialPage");
        var method = metadata.GetMethodDefinition(methodHandle);
        var il = pe.GetMethodBody(method.RelativeVirtualAddress).GetILBytes()
            ?? throw new InvalidOperationException("Method has no IL.");
        var opcodes = typeof(OpCodes).GetFields(BindingFlags.Public | BindingFlags.Static)
            .Where(field => field.FieldType == typeof(OpCode))
            .Select(field => (OpCode)field.GetValue(null)!)
            .ToDictionary(opcode => unchecked((ushort)opcode.Value));
        var target = -1;
        string? lastString = null;
        for (var cursor = 0; cursor < il.Length;)
        {
            var offset = cursor;
            ushort value = il[cursor++];
            if (value == 0xFE) value = (ushort)(0xFE00 | il[cursor++]);
            var opcode = opcodes[value];
            if (opcode == OpCodes.Ldstr)
                lastString = metadata.GetUserString(
                    MetadataTokens.UserStringHandle(BitConverter.ToInt32(il, cursor) & 0x00FFFFFF));
            if (opcode == OpCodes.Throw && lastString == "COORD_OFFICIAL_DESCRIPTOR")
            {
                target = offset;
                break;
            }
            cursor += opcode.OperandType switch
            {
                OperandType.InlineNone => 0,
                OperandType.ShortInlineBrTarget or OperandType.ShortInlineI or OperandType.ShortInlineVar => 1,
                OperandType.InlineVar => 2,
                OperandType.InlineI8 or OperandType.InlineR => 8,
                OperandType.InlineSwitch => 4 + 4 * BitConverter.ToInt32(il, cursor),
                _ => 4,
            };
        }
        if (target < 0) throw new InvalidOperationException("Descriptor rejection was not located.");
        var section = pe.PEHeaders.SectionHeaders.Single(header =>
            method.RelativeVirtualAddress >= header.VirtualAddress
            && method.RelativeVirtualAddress < header.VirtualAddress + Math.Max(header.VirtualSize, header.SizeOfRawData));
        var body = section.PointerToRawData + method.RelativeVirtualAddress - section.VirtualAddress;
        var headerSize = (bytes[body] & 3) switch
        {
            2 => 1,
            3 => (BitConverter.ToUInt16(bytes, body) >> 12) * 4,
            _ => throw new InvalidOperationException("Unknown IL header."),
        };
        var position = body + headerSize + target;
        if (bytes[position] != 0x7A) throw new InvalidOperationException("Target is not throw.");
        bytes[position] = 0x26;
        File.WriteAllBytes(args[1], bytes);
        Console.WriteLine(JsonSerializer.Serialize(new
        {
            method = "SqliteWatcherObservationStore.ProjectOfficialPage",
            token = MetadataTokens.GetToken(methodHandle),
            ilOffset = target,
            fileOffset = position,
            change = "descriptor rejection throw -> pop; one isolated byte",
            beforeSha256 = before,
            afterSha256 = Convert.ToHexString(SHA256.HashData(bytes)),
        }));
    }
}

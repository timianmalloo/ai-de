import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(r"C:\Projects\ai-de-feature-xh-p2-projection")
HERE = Path(__file__).parent
OUT = HERE / "receipt-recovery-raw"
OUT.mkdir(exist_ok=True)
SOURCE = ROOT / "src/AiDe.Core/Watcher/SqliteWatcherObservationStore.OfficialProjection.cs"
CAPTURE = ROOT / "src/AiDe.Core/Watcher/CanonicalCoordinationOfficialCapture.cs"
TEST = ROOT / "tests/AiDe.Core.Tests/Watcher/CanonicalCoordinationProjectionRuntimeTests.cs"
NS = {"t": "http://microsoft.com/schemas/VisualStudio/TeamTest/2010"}
OLD = ROOT / "spikes/canonical-coordination-contract/records/official-runtime/raw-receipts.zip"
with zipfile.ZipFile(OLD) as archive:
    old_trx = ET.fromstring(archive.read("final-staged-runtime.trx"))
CLASSES = sorted({n.attrib["className"].split(",")[0] for n in old_trx.findall(".//t:TestMethod", NS)})
FILTER = "|".join("FullyQualifiedName~" + name for name in CLASSES)
RUNTIME = "FullyQualifiedName~CanonicalCoordinationProjectionRuntimeTests"


def pins():
    paths = [SOURCE, CAPTURE, TEST, ROOT / "src/AiDe.Core/AiDe.Core.csproj",
             ROOT / "tests/AiDe.Core.Tests/AiDe.Core.Tests.csproj",
             *sorted((ROOT / "src/AiDe.Core/Watcher").glob("*Canonical*.cs")),
             *sorted((ROOT / "src/AiDe.Core/Watcher").glob("*Coordination*.cs")),
             *sorted((ROOT / "tests/AiDe.Core.Tests/bin/Debug/net10.0").glob("AiDe*.dll")),
             ROOT / "spikes/canonical-coordination-contract/records/validator-oracle.json"]
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in paths if p.exists()}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2), encoding="utf-8")


def run(label, selection, no_build=False):
    for suffix in (".before-sha256.json", ".after-sha256.json", ".stdout.txt",
                   ".stderr.txt", ".result.json", ".trx"):
        existing = OUT / (label + suffix)
        if existing.exists():
            index = 0
            while (OUT / (label + f".previous-{index}" + suffix)).exists():
                index += 1
            existing.rename(OUT / (label + f".previous-{index}" + suffix))
    save(label + ".before-sha256.json", pins())
    args = ["dotnet", "test", str(ROOT / "tests/AiDe.Core.Tests/AiDe.Core.Tests.csproj"),
            "--no-restore", "--filter", selection, "--logger", f"trx;LogFileName={label}.trx",
            "--results-directory", str(OUT), "--verbosity", "minimal"]
    if no_build:
        args.append("--no-build")
    started = time.monotonic()
    result = subprocess.run(args, cwd=ROOT, capture_output=True, timeout=180)
    (OUT / (label + ".stdout.txt")).write_bytes(result.stdout)
    (OUT / (label + ".stderr.txt")).write_bytes(result.stderr)
    trx = OUT / (label + ".trx")
    counters = {}
    failures = []
    if trx.exists():
        document = ET.parse(trx)
        counters = document.find(".//t:Counters", NS).attrib
        failures = [{"test": n.attrib["testName"], "message": "".join(n.itertext())}
                    for n in document.findall(".//t:UnitTestResult", NS) if n.attrib["outcome"] == "Failed"]
    receipt = {"command": args, "exit": result.returncode, "seconds": time.monotonic() - started,
               "counters": counters, "failures": failures}
    save(label + ".result.json", receipt)
    save(label + ".after-sha256.json", pins())
    print(json.dumps({"run": label, "exit": receipt["exit"], "counters": counters,
                      "failures": [{"test": f["test"], "message": f["message"][:500]}
                                   for f in failures]}, indent=2), flush=True)
    if not counters:
        print(result.stdout.decode(errors="replace"), result.stderr.decode(errors="replace"), flush=True)
    return receipt


def green(receipt, minimum):
    assert receipt["exit"] == 0 and int(receipt["counters"]["passed"]) >= minimum
    assert int(receipt["counters"]["failed"]) == 0


def mutant(label, old, replacement, focal):
    original = SOURCE.read_bytes()
    text = original.decode("utf-8")
    assert text.count(old) == 1, (label, text.count(old))
    try:
        SOURCE.write_bytes(text.replace(old, replacement).encode("utf-8"))
        receipt = run(label, RUNTIME)
        assert receipt["exit"] != 0 and any(focal in failure["test"] for failure in receipt["failures"])
    finally:
        SOURCE.write_bytes(original)
    assert SOURCE.read_bytes() == original
    save(label + ".restoration.json", {"sha256": hashlib.sha256(original).hexdigest(), "restored": True})


if sys.argv[1] == "red":
    (OUT / "pre-edit-baseline-sha256.json").write_bytes((HERE / "recovery-baseline-pins.json").read_bytes())
    green(run("recovery-baseline", FILTER, True), 296)
    red = run("recovery-red", RUNTIME)
    assert red["exit"] != 0 and any("LostAckThenOtherProjectorAdvances" in f["test"]
                                   and "COORD_STALE_SNAPSHOT" in f["message"] for f in red["failures"])
elif sys.argv[1] == "qualify":
    restored = SOURCE.read_bytes()
    old_source = subprocess.run(
        ["git", "show", "e3330489ecc18c6deed02d8d9fa832aaaae77281:src/AiDe.Core/Watcher/SqliteWatcherObservationStore.OfficialProjection.cs"],
        cwd=ROOT, check=True, capture_output=True).stdout
    baseline = json.loads((HERE / "recovery-baseline-pins.json").read_text())
    assert hashlib.sha256(old_source).hexdigest() == baseline[str(SOURCE.relative_to(ROOT))]
    try:
        SOURCE.write_bytes(old_source)
        exact_red = run("recovery-exact-original-red",
                        "FullyQualifiedName~LostAckThenOtherProjectorAdvances|FullyQualifiedName~ConcurrentLostAckAndAdvance")
        assert exact_red["exit"] == 1 and int(exact_red["counters"]["failed"]) == 2
        assert all("COORD_STALE_SNAPSHOT" in f["message"] for f in exact_red["failures"])
    finally:
        SOURCE.write_bytes(restored)
    green(run("recovery-green", FILTER), 311)
    mutant("recovery-guard-mutant",
           "if (current is not null && current.Offset >= page.End)",
           "if (current is not null && current.Offset >= page.End && current.Offset <= page.SnapshotLength)",
           "LostAckThenOtherProjectorAdvances")
    mutant("recovery-validation-mutant",
           "foreach (var (offset, end) in page.PrefixFrames())",
           "foreach (var (offset, end) in page.Frames())",
           "ChangedSemanticOrEarlierPrefix")
elif sys.argv[1] == "final":
    green(run("recovery-final", FILTER), 311)
    old_names = {n.attrib["testName"] for n in old_trx.findall(".//t:UnitTestResult", NS)}
    current_trx = ET.parse(OUT / "recovery-final.trx")
    current_names = {n.attrib["testName"] for n in current_trx.findall(".//t:UnitTestResult", NS)}
    assert old_names <= current_names
    save("recovery-inventory.json", {"original_cases": len(old_names),
                                    "final_cases": len(current_names), "missing": sorted(old_names - current_names)})
    (OUT / "verification-recipe.py").write_bytes(Path(__file__).read_bytes())
    target = ROOT / "spikes/canonical-coordination-contract/records/official-runtime"
    with zipfile.ZipFile(target / "receipt-recovery-raw.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(OUT.iterdir()):
            archive.write(path, path.name)
    (target / "receipt-recovery-manifest.json").write_text(json.dumps(
        {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.iterdir())}, indent=2))

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter

root = Path(r"C:\Projects\ai-de-feature-xh-p2-projection")
output = Path(__file__).parent / "official-runtime"
output.mkdir(exist_ok=True)
label = sys.argv[1]
selector = ("FullyQualifiedName~CanonicalCoordination|FullyQualifiedName~CoordinationProjectionTests|"
            "FullyQualifiedName~CoordinationProjectionBoundaryTests|"
            "FullyQualifiedName~CoordinationRecoveryBoundaryTests|FullyQualifiedName~CoordinationFeedTests")
if len(sys.argv) > 2:
    selector = sys.argv[2]
patterns = ("src/AiDe.Core/Watcher/*.cs", "tests/AiDe.Core.Tests/Watcher/*Coordination*.cs",
            "**/*.csproj", "Directory.*.props", "global.json",
            "tests/AiDe.Core.Tests/Watcher/Fixtures/canonical*.json",
            "spikes/canonical-coordination-contract/records/*.json",
            "tests/AiDe.Core.Tests/bin/Debug/net10.0/AiDe.Core*.dll")

def pins():
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for pattern in patterns for p in sorted(root.glob(pattern)) if p.is_file()}

def write(name, value):
    (output / name).write_text(json.dumps(value, indent=2), encoding="utf-8")

if label == "seal":
    target = root / "spikes/canonical-coordination-contract/records/official-runtime"
    target.mkdir(exist_ok=True)
    receipts = sorted(p for p in output.iterdir() if p.is_file())
    manifest = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in receipts}
    with zipfile.ZipFile(target / "raw-receipts.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for p in receipts:
            archive.write(p, p.name)
    with zipfile.ZipFile(target / "raw-receipts.zip") as archive:
        assert all(hashlib.sha256(archive.read(n)).hexdigest() == h for n, h in manifest.items())
    (target / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({"sealed": len(manifest), "archive": str(target / "raw-receipts.zip")}))
    sys.exit(0)

write(f"{label}.before-sha256.json", pins())
command = ["dotnet", "test", str(root / "tests/AiDe.Core.Tests/AiDe.Core.Tests.csproj"),
           "--no-restore", "--filter", selector, "--logger", f"trx;LogFileName={label}.trx",
           "--results-directory", str(output), "--verbosity", "quiet"]
started = time.monotonic()
result = subprocess.run(command, cwd=root, capture_output=True)
(output / f"{label}.stdout.txt").write_bytes(result.stdout)
(output / f"{label}.stderr.txt").write_bytes(result.stderr)
record = {"command": command, "exit": result.returncode, "seconds": time.monotonic() - started}
trx = output / f"{label}.trx"
if trx.exists():
    document = ET.parse(trx)
    ns = {"t": "http://microsoft.com/schemas/VisualStudio/TeamTest/2010"}
    record["counters"] = document.find(".//t:Counters", ns).attrib
    results = document.findall(".//t:UnitTestResult", ns)
    record["classes"] = dict(Counter(r.attrib["testName"].split("(")[0].rsplit(".", 1)[0] for r in results))
    record["failed"] = [{"name": r.attrib["testName"],
                         "message": r.findtext(".//t:Message", namespaces=ns)}
                        for r in results if r.attrib["outcome"] != "Passed"]
write(f"{label}.after-sha256.json", pins())
write(f"{label}.result.json", record)
print(json.dumps(record, indent=2))
if not trx.exists():
    print(result.stdout.decode("utf-8", errors="replace")[-6000:])
    print(result.stderr.decode("utf-8", errors="replace")[-2000:])
sys.exit(result.returncode)
